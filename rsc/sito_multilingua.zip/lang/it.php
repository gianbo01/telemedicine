<?php 

 $TITOLO = "Sito multilingua";
 $TESTO = "Benvenuto in questo sito multilingua. Scegli la lingua con i pulsanti qui in basso. </br> Questo sito è stato creato da <a href=&quot;www.byte-post.com&quot;>Byte-Post.com</a>";
 $LINGUA = "Italiano";
 
?>