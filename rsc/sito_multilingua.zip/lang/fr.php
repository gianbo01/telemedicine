<?php 

 $TITOLO = "Site multilingue";
 $TESTO = "Bienvenue sur ce site multilingue. Choisissez votre langue avec les boutons ci-dessous. </br> Ce site a été créé par <a href=&quot;www.byte-post.com&quot;>Byte-Post.com</a>";
 $LINGUA = "Français";
 
?>