<?php 

 $TITOLO = "Multilingual website";
 $TESTO = "Welcome to this multilingual site. Choose your language with the buttons below. </br> This site was created by <a href=&quot;www.byte-post.com&quot;>Byte-Post.com</a>";
 $LINGUA = "English";
 
?>